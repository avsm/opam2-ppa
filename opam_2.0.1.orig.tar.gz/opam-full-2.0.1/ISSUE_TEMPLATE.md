>   If your issue concerns a package not building, please report to
>   https://github.com/ocaml/opam-repository/issues or to the package maintainer
>   unless you are confident it is an issue in the opam tool itself.

```
<include here the output of `opam config report`, if applicable>
```
